#feature-id RGBStarAlign : ChickadeeScripts > RGNStarAlign
#feature-icon  RGBStarAlign.svg
#feature-info This script aligns the peaks of RGB stars across an image



#include "STDCommon.js"

#define VERSION "v1.0.0 beta"


// Define platform-agnostic folder paths
let pathSeparator = (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows") ? "\\" : "/";
let scriptTempDir = File.systemTempDirectory + pathSeparator + "RGBAlignConfig";
let scriptConfigFile = scriptTempDir + pathSeparator + "RGBAlign_config.csv";

// Ensure the temp directory exists
if (!File.directoryExists(scriptTempDir)) {
   File.createDirectory(scriptTempDir);
}


// Define global parameters
var globalParameters = {
   targetView: undefined,
   targetWindow: undefined,
   strideSize: 1024,
   maxDistortion: 0.6,
   sensitivity: 0.5,
   structureLayers: 5,
   xyStretch: 1.5,
   peakResponse: 0.5,
   linearImage: true,
   replaceWithSS: true,
   keepSyntheticStars: true,
   ignoreHotPixels: true,
   SSdenoiseFirst: true,
   SSdenoiseWithNN: false,
   SSdenoiseWithMMT: true,
   SSlinearCheckBox: true,
   recombinationMethod: 'op_screen',
   SSrecombinationExtraPercent: 0.5,
   SSminimumStarSize: 0,
   starDetectorStars: [],
   dynamicPSFStars: [],
   SSstarSizeRange: 10,
   SSstarIntensityRange: 0.04,
   RGBStarLists: [],
   RGXfactor: 1,
   RGYfactor: 1,
   RBXfactor: 1,
   RBYfactor: 1,
   RGBAlignCorner: 'TopLeft',
   RGBAlignCornerPercent: 0.1,

   save: function () {
      Parameters.set("maxDistortion", this.maxDistortion);
      Parameters.set("sensitivity", this.sensitivity);
      Parameters.set("structureLayers", this.structureLayers);
      Parameters.set("xyStretch", this.xyStretch);
      Parameters.set("peakResponse", this.peakResponse);
      Parameters.set("SSminimumStarSize", this.SSminimumStarSize);
      Parameters.set("SSdenoiseFirst", this.SSdenoiseFirst);
      Parameters.set("SSdenoiseWithNN", this.SSdenoiseWithNN);
      Parameters.set("SSdenoiseWithMMT", this.SSdenoiseWithMMT);
      Parameters.set("replaceWithSS", this.replaceWithSS);
      Parameters.set("keepSyntheticStars", this.keepSyntheticStars);
      Parameters.set("SSlinearCheckBox", this.SSlinearCheckBox);
      Parameters.set("recombinationMethod", this.recombinationMethod);
      Parameters.set("SSrecombinationExtraPercent", this.SSrecombinationExtraPercent);
      Parameters.set("SSstarIntensityRange", this.SSstarIntensityRange);
      Parameters.set("RGBAlignCorner", this.RGBAlignCorner);
      Parameters.set("RGBAlignCornerPercent", this.RGBAlignCornerPercent);
      Parameters.set("RGXfactor", this.RGXfactor);
      Parameters.set("RGYfactor", this.RGYfactor);
      Parameters.set("RBXfactor", this.RBXfactor);
      Parameters.set("RBYfactor", this.RBYfactor);
      this.savePathToFile();
   },

   load: function () {
      if (Parameters.has("maxDistortion"))
         this.maxDistortion = Number(Parameters.getString("maxDistortion"));
      if (Parameters.has("sensitivity"))
         this.sensitivity = Number(Parameters.getString("sensitivity"));
      if (Parameters.has("structureLayers"))
         this.structureLayers = Number(Parameters.getString("structureLayers"));
      if (Parameters.has("xyStretch"))
         this.xyStretch = Number(Parameters.getString("xyStretch"));
      if (Parameters.has("peakResponse"))
         this.peakResponse = Number(Parameters.getString("peakResponse"));
      if (Parameters.has("SSminimumStarSize"))
         this.SSminimumStarSize = Number(Parameters.getString("SSminimumStarSize"));
      if (Parameters.has("SSdenoiseFirst"))
         this.SSdenoiseFirst = Number(Parameters.getString("SSdenoiseFirst"));
      if (Parameters.has("SSdenoiseWithNN"))
         this.SSdenoiseWithNN = Number(Parameters.getString("SSdenoiseWithNN"));
      if (Parameters.has("SSdenoiseWithMMT"))
         this.SSdenoiseWithMMT = Number(Parameters.getString("SSdenoiseWithMMT"));
      if (Parameters.has("replaceWithSS"))
         this.replaceWithSS = Number(Parameters.getString("replaceWithSS"));
      if (Parameters.has("SSlinearCheckBox"))
         this.SSlinearCheckBox = Number(Parameters.getString("SSlinearCheckBox"));
      if (Parameters.has("keepSyntheticStars"))
         this.keepSyntheticStars = Number(Parameters.getString("keepSyntheticStars"));
      if (Parameters.has("recombinationMethod"))
         this.recombinationMethod = String(Parameters.getString("recombinationMethod"));
      if (Parameters.has("SSrecombinationExtraPercent"))
         this.SSrecombinationExtraPercent = Number(Parameters.getString("SSrecombinationExtraPercent"));
      if (Parameters.has("SSstarIntensityRange"))
         this.SSstarIntensityRange = Number(Parameters.getString("SSstarIntensityRange"));
      if (Parameters.has("RGBAlignCorner"))
         this.RGBAlignCorner = String(Parameters.getString("RGBAlignCorner"));
      if (Parameters.has("RGBAlignCornerPercent"))
         this.RGBAlignCornerPercent = Number(Parameters.getString("RGBAlignCornerPercent"));
      if (Parameters.has("RGXfactor"))
         this.RGXfactor = Number(Parameters.getString("RGXfactor"));
      if (Parameters.has("RGYfactor"))
         this.RGYfactor = Number(Parameters.getString("RGYfactor"));
      if (Parameters.has("RBXfactor"))
         this.RBXfactor = Number(Parameters.getString("RBXfactor"));
      if (Parameters.has("RBYfactor"))
         this.RBYfactor = Number(Parameters.getString("RBYfactor"));
      this.loadPathFromFile();
   },
   savePathToFile: function () {
      try {
         let file = new File;
         
         file.createForWriting(scriptConfigFile);
         file.outTextLn(String(this.maxDistortion));
         file.outTextLn(String(this.sensitivity));
         file.outTextLn(String(this.structureLayers));
         file.outTextLn(String(this.xyStretch));
         file.outTextLn(String(this.peakResponse));
         file.outTextLn(String(this.SSminimumStarSize));
         file.outTextLn(String(Number(this.SSdenoiseFirst)));
         file.outTextLn(String(Number(this.SSdenoiseWithNN)));
         file.outTextLn(String(Number(this.SSdenoiseWithMMT)));
         file.outTextLn(String(Number(this.replaceWithSS)));
         file.outTextLn(String(Number(this.SSlinearCheckBox)));
         file.outTextLn(String(Number(this.keepSyntheticStars)));
         file.outTextLn(String(this.recombinationMethod));
         file.outTextLn(String(this.SSrecombinationExtraPercent));
         file.outTextLn(String(this.SSstarIntensityRange));
         file.outTextLn(String(this.RGBAlignCorner));
         file.outTextLn(String(this.RGBAlignCornerPercent));
         file.outTextLn(String(this.RGXfactor));
         file.outTextLn(String(this.RGYfactor));
         file.outTextLn(String(this.RBXfactor));
         file.outTextLn(String(this.RBYfactor));
         file.close();
      } catch (error) {
         console.warningln("Failed to save scriptConfigFile: " + error.message);
      }
   },

   loadPathFromFile: function () {
      try {
         if (File.exists(scriptConfigFile)) {
            let file = new File;
            // console.writeln("Reading config file: " + scriptConfigFile);
            file.openForReading(scriptConfigFile);
            let lines = File.readLines(scriptConfigFile);
            if (lines.length > 0) {
               this.maxDistortion = Number(lines[0].trim());
               this.sensitivity = Number(lines[1].trim());
               this.structureLayers = Number(lines[2].trim());
               this.xyStretch = Number(lines[3].trim());
               this.peakResponse = Number(lines[4].trim());
               this.SSminimumStarSize = Number(lines[5].trim());
               this.SSdenoiseFirst = Boolean(Number(lines[6].trim()));
               this.SSdenoiseWithNN = Boolean(Number(lines[7].trim()));
               this.SSdenoiseWithMMT = Boolean(Number(lines[8].trim()));
               this.replaceWithSS = Boolean(Number(lines[9].trim()));
               this.SSlinearCheckBox = Boolean(Number(lines[10].trim()));
               this.keepSyntheticStars = Boolean(Number(lines[11].trim()));
               this.recombinationMethod = String(lines[12].trim());
               this.SSrecombinationExtraPercent = Number(lines[13].trim());
               this.SSstarIntensityRange = Number(lines[14].trim());
               this.RGBAlignCorner = String(lines[15].trim());
               this.RGBAlignCornerPercent = Number(lines[16].trim());
               this.RGXfactor = Number(lines[17].trim());
               this.RGYfactor = Number(lines[18].trim());
               this.RBXfactor = Number(lines[19].trim());
               this.RBYfactor = Number(lines[20].trim());
            }
            file.close();
         }
      } catch (error) {
         console.warningln("Failed to load scriptConfigFile: " + error.message);
      }
   }
};



// Dialog setup, image selection, etc.
function MainDialog() {
   this.__base__ = Dialog;
   this.__base__();

   console.hide();
   globalParameters.load();

   this.title = new Label(this);
   this.title.text = "RGBStarAlign " + VERSION;
   this.title.textAlignment = TextAlign_Center;

   this.description = new TextBox(this);
   this.description.readOnly = true;
   this.description.height = 90;
   this.description.maxHeight = 90;
   this.description.text = "This script is meant to address the issues of imperfect demosaicing and chromatic aberration due to RGB misalignment. It partitions an RGB image into regions, with smaller regions around the image edge, " +
      "and then detects the peaks of the smallest stars in each of the RGB planes. It then determines the misalignment of each region with respect to the RGB peaks of the smaller stars and aligns them.\n" +
      "";
   this.description.setMinWidth(800);
   

   this.imageSelectionLabel = new Label(this);
   this.imageSelectionLabel.text = "Select Image:";
   this.imageSelectionLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.imageSelectionDropdown = new ComboBox(this);
   this.imageSelectionDropdown.editEnabled = false;

   this.imageSelectionDropdown.onItemSelected = (index) => {
      if (index >= 0) {
         let window = ImageWindow.windowById(this.imageSelectionDropdown.itemText(index));
         if (window && !window.isNull) {
            globalParameters.targetWindow = window;
         } else {
            console.writeln("No valid window selected for preview!");
            // this.previewControl.visible = false;
            // this.zoomSizer.visible = false;
            this.adjustToContents();
         }
      }
   };

   let windows = ImageWindow.windows;
   let activeWindowId = ImageWindow.activeWindow.mainView.id;
   for (let i = 0; i < windows.length; ++i) {
      this.imageSelectionDropdown.addItem(windows[i].mainView.id);
      if (windows[i].mainView.id === activeWindowId) {
         this.imageSelectionDropdown.currentItem = i;
         globalParameters.targetWindow = windows[i];
      }
   }

   this.imageSelectionSizer = new HorizontalSizer;
   this.imageSelectionSizer.spacing = 4;
   this.imageSelectionSizer.add(this.imageSelectionLabel);
   this.imageSelectionSizer.add(this.imageSelectionDropdown, 100);

   var dlg = this;


   


   this.SSdenoiseFirst = new CheckBox(this);
   with (this.SSdenoiseFirst) {
      toolTip = "Denoising tends to increase the number of stars detected\nBoth tools can be used sequentially to improve star detection"
      text = "Denoise prior to detection";
      enabled = true;
      checked = globalParameters.SSdenoiseFirst;
      bindings = function () {
         this.checked = globalParameters.SSdenoiseFirst;
      }
      onCheck = function (value) {
         globalParameters.SSdenoiseFirst = value;
         dlg.SSdenoiseWithNN.enabled = value;
         dlg.SSdenoiseWithMMT.enabled = value;
      }
   }

   this.SSdenoiseWithNN = new CheckBox(this);
   with (this.SSdenoiseWithNN) {
      toolTip = "Denoise using machine language denoiser that comes with this script"
      text = "Denoise with ML denoiser";
      // enabled = globalParameters.SSdenoiseFirst;
      enabled = false;
      visible = false;
      checked = globalParameters.SSdenoiseWithNN;
      bindings = function () {
         this.checked = globalParameters.SSdenoiseWithNN;
      }
      onCheck = function (value) {
         globalParameters.SSdenoiseWithNN = value;
      }
   }

   this.SSdenoiseWithMMT = new CheckBox(this);
   with (this.SSdenoiseWithMMT) {
      toolTip = "Denoise using Multiscale Median Transform noise reduction"
      text = "Denoise with MMT";
      enabled = globalParameters.SSdenoiseFirst;
      checked = globalParameters.SSdenoiseWithMMT;
      bindings = function () {
         this.checked = globalParameters.SSdenoiseWithMMT;
      }
      onCheck = function (value) {
         globalParameters.SSdenoiseWithMMT = value;
      }
   }


   this.SSpreprocessGB = new GroupBox(this);
   with (this.SSpreprocessGB) {
      sizer = new HorizontalSizer;
      title = "Preprocessing";
      enabled = true;

      sizer.add(this.SSdenoiseFirst);
      sizer.spacing = 6;
      sizer.add(this.SSdenoiseWithNN);
      sizer.spacing = 6;
      sizer.add(this.SSdenoiseWithMMT);
      sizer.spacing = 6;
      sizer.addStretch();

   }


   this.syntheticStarsButtonTab = new PushButton(this);
   this.syntheticStarsButtonTab.text = "Test Star Detector";
   this.syntheticStarsButtonTab.onClick = function () {
      var parent = this.parent;
      var grandparent = parent.parent;
      var greatgrandparent = grandparent.parent;
      var useStarSizeRange = false;
      var filterByIntensity = false;
      let returnedStars = createSyntheticStars(globalParameters.targetWindow.mainView, dlg, useStarSizeRange, filterByIntensity);
      globalParameters.save();

      Console.writeln('Number of stars returned by detector: ' + returnedStars.length);
   };

   this.syntheticStarsButtonSizerTab = new HorizontalSizer;
   this.syntheticStarsButtonSizerTab.spacing = 4;
   this.syntheticStarsButtonSizerTab.add(this.syntheticStarsButtonTab);
   /*
   std.sensitivity = Math.pow(10.0, -5.0);
   std.xyStretch = 1.5;
   std.maxDistortion = 0.1;
   std.minStructSize = 0;
   */


   this.SSsensitivity = new NumericControl(this);
   this.SSsensitivity.label.text = "Sensitivity:";
   this.SSsensitivity.toolTip = "Increasing numbers increases the number of stars detected\nHigher numbers may erroneously detect non-star objects as stars";
   this.SSsensitivity.setRange(0, 1);
   this.SSsensitivity.setPrecision(2);
   this.SSsensitivity.setValue(globalParameters.sensitivity);
   this.SSsensitivity.onValueUpdated = (value) => {
      globalParameters.sensitivity = value;
   };

   this.SSsensitivitySizer = new HorizontalSizer;
   this.SSsensitivitySizer.spacing = 4;
   this.SSsensitivitySizer.add(this.SSsensitivity);

   this.SSstructureLayers = new NumericControl(this);
   this.SSstructureLayers.label.text = "Structure layers:";
   this.SSstructureLayers.toolTip = "Increasing numbers increases the number of stars detected\nHigher numbers may erroneously detect non-star objects as stars";
   this.SSstructureLayers.setRange(1, 12);
   this.SSstructureLayers.setPrecision(0);
   this.SSstructureLayers.setValue(globalParameters.structureLayers);
   this.SSstructureLayers.onValueUpdated = (value) => {
      globalParameters.structureLayers = value;
   };

   this.SSstructureLayersSizer = new HorizontalSizer;
   this.SSstructureLayersSizer.spacing = 4;
   this.SSstructureLayersSizer.add(this.SSstructureLayers);


   this.SSxyStretch = new NumericControl(this);
   this.SSxyStretch.label.text = "XY stretch:";
   this.SSxyStretch.toolTip = "Stretch factor for the barycenter search algorithm, in sigma units.\nIncrease it to make the algorithm more robust to nearby structures, \nsuch as multiple / crowded stars and small nebular features.\nHowever, too large of a stretch factor will make the algorithm less accurate.";
   this.SSxyStretch.setRange(1, 3);
   this.SSxyStretch.setPrecision(1);
   this.SSxyStretch.setValue(globalParameters.xyStretch);
   this.SSxyStretch.onValueUpdated = (value) => {
      globalParameters.xyStretch = value;
   };

   this.SSxyStretchSizer = new HorizontalSizer;
   this.SSxyStretchSizer.spacing = 4;
   this.SSxyStretchSizer.add(this.SSxyStretch);

   this.SSpeakResponse = new NumericControl(this);
   this.SSpeakResponse.label.text = "Peak response:";
   this.SSpeakResponse.toolTip = "If you decrease this parameter, stars will need to have stronger(or more prominent) \npeaks to be detected.This is useful to prevent detection of saturated stars, \nas well as small nonstellar features.By increasing this parameter, \nthe star detection algorithm will be more sensitive to peakedness, \nand hence more tolerant with relatively flat image features.\n\nA higher number detects more objects.";
   this.SSpeakResponse.setRange(0, 1);
   this.SSpeakResponse.setPrecision(2);
   this.SSpeakResponse.setValue(globalParameters.peakResponse);
   this.SSpeakResponse.onValueUpdated = (value) => {
      globalParameters.peakResponse = value;
   };

   this.SSpeakResponseSizer = new HorizontalSizer;
   this.SSpeakResponseSizer.spacing = 4;
   this.SSpeakResponseSizer.add(this.SSpeakResponse);


   this.SSminimumStarSize = new NumericControl(this);
   this.SSminimumStarSize.label.text = "Min star size:";
   this.SSminimumStarSize.toolTip = "If you decrease this parameter, smaller star will be included by the size specified.\nIf you increase the parameter, smaller stars will be excluded.\nThis might be useful to exclude small stars erroneously detected from noise.";
   this.SSminimumStarSize.setRange(0, 100);
   this.SSminimumStarSize.setPrecision(0);
   this.SSminimumStarSize.setValue(globalParameters.SSminimumStarSize);
   this.SSminimumStarSize.onValueUpdated = (value) => {
      globalParameters.SSminimumStarSize = value;
   };

   this.SSminimumStarSizeSizer = new HorizontalSizer;
   this.SSminimumStarSizeSizer.spacing = 4;
   this.SSminimumStarSizeSizer.add(this.SSminimumStarSize);





   this.SSmaxDistortion = new NumericControl(this);
   this.SSmaxDistortion.label.text = "Max distortion:";
   this.SSmaxDistortion.toolTip = "Use this parameter, if necessary, to control inclusion of elongated stars, \ncomplex clusters of stars, and nonstellar image features.";
   this.SSmaxDistortion.setRange(0, 1);
   this.SSmaxDistortion.setPrecision(2);
   // this.SSmaxDistortion.slider.setRange(0, 1);
   // this.SSmaxDistortion.setValue(0.4);
   this.SSmaxDistortion.setValue(globalParameters.maxDistortion);
   // this.starSizeSlider.hide(); // Hide initially
   this.SSmaxDistortion.onValueUpdated = (value) => {
      globalParameters.maxDistortion = value;
   };

   this.SSmaxDistortionSizer = new HorizontalSizer;
   this.SSmaxDistortionSizer.spacing = 4;
   this.SSmaxDistortionSizer.add(this.SSmaxDistortion);


   this.ignoreHotPixels = new CheckBox(this);
   with (this.ignoreHotPixels) {
      toolTip = "Check if you want the star detector to ignore hot pixels"
      text = "Ignore hot pixels";
      enabled = true;
      checked = globalParameters.ignoreHotPixels;
      bindings = function () {
         this.checked = globalParameters.ignoreHotPixels;
      }
      onCheck = function (value) {
         globalParameters.ignoreHotPixels = value;
      }
   }



   this.SSstarDetectionGB = new GroupBox(this);
   with (this.SSstarDetectionGB) {
      sizer = new VerticalSizer;
      title = "Star Detection";
      enabled = true;

      sizer.add(this.SSsensitivitySizer);
      sizer.spacing = 6;
      sizer.add(this.SSstructureLayersSizer);
      sizer.spacing = 6;
      sizer.add(this.SSxyStretchSizer);
      sizer.spacing = 6;
      sizer.add(this.SSmaxDistortionSizer);
      sizer.spacing = 6;
      sizer.add(this.SSpeakResponseSizer);
      sizer.spacing = 6;
      sizer.add(this.SSminimumStarSizeSizer);
      sizer.spacing = 6;
      sizer.add(this.ignoreHotPixels);
      sizer.spacing = 6;
      sizer.addStretch();

   }


   this.replaceWithSS = new CheckBox(this);
   with (this.replaceWithSS) {
      toolTip = "Check if you want to use StarNet2 to replace the stars on the image with the synthetic stars"
      text = "Replace stars with synthetic stars";
      enabled = true;
      checked = globalParameters.replaceWithSS;
      bindings = function () {
         this.checked = globalParameters.replaceWithSS;
      }
      onCheck = function (value) {
         globalParameters.replaceWithSS = value;
      }
   }

   this.keepSyntheticStars = new CheckBox(this);
   with (this.keepSyntheticStars) {
      toolTip = "Check if you want to keep the generated synthetic stars image"
      text = "Keep synthetic stars image";
      enabled = true;
      checked = globalParameters.keepSyntheticStars;
      bindings = function () {
         this.checked = globalParameters.keepSyntheticStars;
      }
      onCheck = function (value) {
         globalParameters.keepSyntheticStars = value;
      }
   }

   this.SSlinearCheckBox = new CheckBox(this);
   with (this.SSlinearCheckBox) {
      toolTip = "Check if this is a linear image for star replacement with StarNet2"
      text = "Linear data";
      enabled = true;
      checked = globalParameters.SSlinearCheckBox;
      bindings = function () {
         this.checked = globalParameters.SSlinearCheckBox;
      }
      onCheck = function (value) {
         globalParameters.SSlinearCheckBox = value;
      }
   }


   this.recombinationMethodComboBox = new ComboBox(this);
   this.recombinationMethodComboBox.toolTip = "Select the method by which the stars are recombined with the starless image\nThe recombination method uses PixelMath\nmaximum uses max(starless,stars)\nop_screen uses combine(starless,stars,op_screen())";
   this.recombinationMethodComboBox.addItem("maximum");
   this.recombinationMethodComboBox.addItem("op_screen");

   this.recombinationMethodComboBox.onItemSelected = (index) => {
      // console.writeln("Setting stride size index: " + index + " from stored: " + globalParameters.strideSize);
      if (index == 0) {
         globalParameters.recombinationMethod = 'maximum';
      }
      else {
         globalParameters.recombinationMethod = 'op_screen';
      }

      // globalParameters.save();
   };



   this.SSrecombinationExtraPercent = new NumericControl(this);
   this.SSrecombinationExtraPercent.label.text = "Recombination factor:";
   this.SSrecombinationExtraPercent.toolTip = "This will add a percentage amount to the peak value to enhance the star above background,\nbut only if the maximum method of recombination is selected.\nThis may be useful for faint stars with peaks close to background\nWarning - at baseline, the algorithm detects and creates stars with their original\ndetected parameters. Using amounts above 0 will make stars more visible, but will\nincrease their maximum peak values on the replaced image.";
   this.SSrecombinationExtraPercent.setRange(0, 1);
   this.SSrecombinationExtraPercent.setPrecision(2);
   // this.SSmaxDistortion.slider.setRange(0, 1);
   // this.SSmaxDistortion.setValue(0.4);
   this.SSrecombinationExtraPercent.setValue(globalParameters.SSrecombinationExtraPercent);
   // this.starSizeSlider.hide(); // Hide initially
   this.SSrecombinationExtraPercent.onValueUpdated = (value) => {
      globalParameters.SSrecombinationExtraPercent = value;
   };

   this.SSrecombinationExtraPercentSizer = new HorizontalSizer;
   this.SSrecombinationExtraPercentSizer.spacing = 4;
   this.SSrecombinationExtraPercentSizer.add(this.SSrecombinationExtraPercent);



   this.SSpostprocessGB = new GroupBox(this);
   with (this.SSpostprocessGB) {
      sizer = new HorizontalSizer;
      title = "Postprocessing";
      enabled = true;

      sizer.add(this.SSlinearCheckBox);
      sizer.spacing = 6;
      sizer.add(this.replaceWithSS);
      sizer.spacing = 6;
      sizer.add(this.keepSyntheticStars);
      sizer.spacing = 6;
      sizer.add(this.recombinationMethodComboBox);
      sizer.spacing = 6;
      sizer.add(this.SSrecombinationExtraPercentSizer);
      sizer.spacing = 6;
      sizer.addStretch();

   }

   this.syntheticStarsGeneratorTab = new Control(this);

   with (this.syntheticStarsGeneratorTab) {
      sizer = new VerticalSizer(this.syntheticStarsGeneratorTab);
      // sizer = new HorizontalSizer;

      sizer.add(this.SSpreprocessGB);
      sizer.spacing = 6;
      sizer.add(this.SSstarDetectionGB);
      sizer.spacing = 6;
      sizer.add(this.SSpostprocessGB);
      sizer.spacing = 6;
      sizer.add(this.syntheticStarsButtonSizerTab);
      sizer.spacing = 6;

      sizer.addStretch();
   }






   this.RGBStarsTab = new Control(this);

   this.RGBStarsDescription = new TextBox(this);
   this.RGBStarsDescription.readOnly = true;
   this.RGBStarsDescription.height = 220;
   this.RGBStarsDescription.maxHeight = 220;
   this.RGBStarsDescription.text = "This tab uses the star detector settings in the accompanying Star Detector Settings tab.\n\n" +
      "RGB Align Full Image works by partitioning the image into 16 regions. The divisions along the image edges are from 0-10%, 10-50%, 50-90%, and 90-100% of both the image width and the height, " +
      "thus creating 16 subframes of unequal sizes. The smaller regions are in the corners, and then the outside edges. This partition was done to optimize the realignment of the RGB channels due to chromatic aberration," +
      "which may be most prominent in the corners and the edges. If there is a global RGB misalignment, the algorithm also addresses this issue. Some denoising prior to alignment helps with the detection of small stars.\n\n" +
      "RGB Align Corner aligns a specified corner by specifying the corner and the percentage of the image defining the corner.\n\n" +
      "The sliders add an extra amount of correction on the shift as needed.";


   this.fixRGBGenerateStarLists = new PushButton(this);
   this.fixRGBGenerateStarLists.text = "RGB Align Full Image";
   this.fixRGBGenerateStarLists.onClick = function () {
      var parent = this.parent;
      var grandparent = parent.parent;
      var greatgrandparent = grandparent.parent;
      Console.show();
      let returnedStars = generateRGBStarLists(globalParameters.targetWindow.mainView, dlg);
      Console.hide();
      // Console.writeln('Number of stars returned by detector: ' + returnedStars.length);
   };

   this.RGBFullImageAlignToolsSizer = new VerticalSizer;
   this.RGBFullImageAlignToolsSizer.title = "Star Detection";
   this.RGBFullImageAlignToolsSizer.enabled = true;
   this.RGBFullImageAlignToolsSizer.addStretch();
   this.RGBFullImageAlignToolsSizer.add(this.fixRGBGenerateStarLists);
   this.RGBFullImageAlignToolsSizer.spacing = 6;
   

   this.RGBAlignCornerButton = new PushButton(this);
   this.RGBAlignCornerButton.text = "RGB Align Corner";
   this.RGBAlignCornerButton.onClick = function () {
      var parent = this.parent;
      var grandparent = parent.parent;
      var greatgrandparent = grandparent.parent;
      Console.show();
      let returnedStars = generateRGBStarLists(globalParameters.targetWindow.mainView, dlg, globalParameters.RGBAlignCornerPercent, globalParameters.RGBAlignCorner, true);
      Console.hide();
      globalParameters.save();
      // Console.writeln('Number of stars returned by detector: ' + returnedStars.length);
   };

   this.RGBAlignCornerComboBox = new ComboBox(this);
   this.RGBAlignCornerComboBox.toolTip = "Select the corner to RGB align\n";
   this.RGBAlignCornerComboBox.addItem("Top Left");
   this.RGBAlignCornerComboBox.addItem("Top Right");
   this.RGBAlignCornerComboBox.addItem("Bottom Left");
   this.RGBAlignCornerComboBox.addItem("Bottom Right");
   if (globalParameters.RGBAlignCorner == 'TopLeft') {
      this.RGBAlignCornerComboBox.currentItem = 0;
   }
   else if (globalParameters.RGBAlignCorner == 'TopRight') {
      this.RGBAlignCornerComboBox.currentItem = 1;
   }
   else if (globalParameters.RGBAlignCorner == 'BottomLeft') {
      this.RGBAlignCornerComboBox.currentItem = 2;
   }
   else {
      this.RGBAlignCornerComboBox.currentItem = 3;
   }

   this.RGBAlignCornerComboBox.onItemSelected = (index) => {
      if (index == 0) {
         globalParameters.RGBAlignCorner = 'TopLeft';
      }
      else if (index == 1) {
         globalParameters.RGBAlignCorner = 'TopRight';
      }
      else if (index == 2) {
         globalParameters.RGBAlignCorner = 'BottomLeft';
      }
      else {
         globalParameters.RGBAlignCorner = 'BottomRight';
      }
   };

   this.RGBAlignCornerPercent = new NumericControl(this);
   this.RGBAlignCornerPercent.label.text = "Percentage of corner to RGB align:";
   this.RGBAlignCornerPercent.toolTip = "This is the percentage amount of the entire image to RGB align\nFor example, a value of 0.1 means that the RGB align will work on 10% width by 10% height (therfore 0.1x0.1, or 1% of the full image).";
   this.RGBAlignCornerPercent.setRange(0, 0.4);
   this.RGBAlignCornerPercent.setPrecision(2);
   // this.SSmaxDistortion.slider.setRange(0, 1);
   // this.SSmaxDistortion.setValue(0.4);
   this.RGBAlignCornerPercent.setValue(globalParameters.RGBAlignCornerPercent);
   // this.starSizeSlider.hide(); // Hide initially
   this.RGBAlignCornerPercent.onValueUpdated = (value) => {
      globalParameters.RGBAlignCornerPercent = value;
   };

   this.RGBAlignCornerPercentSizer = new HorizontalSizer;
   this.RGBAlignCornerPercentSizer.spacing = 4;
   this.RGBAlignCornerPercentSizer.add(this.RGBAlignCornerPercent);


   this.RGBCornerAlignToolsSizer = new VerticalSizer;
   this.RGBCornerAlignToolsSizer.title = "Star Detection";
   this.RGBCornerAlignToolsSizer.enabled = true;

   this.RGBCornerAlignToolsSizer.add(this.RGBAlignCornerComboBox);
   this.RGBCornerAlignToolsSizer.spacing = 6;
   this.RGBCornerAlignToolsSizer.add(this.RGBAlignCornerPercentSizer);
   this.RGBCornerAlignToolsSizer.spacing = 6;
   this.RGBCornerAlignToolsSizer.add(this.RGBAlignCornerButton);
   this.RGBCornerAlignToolsSizer.spacing = 6;
   this.RGBCornerAlignToolsSizer.addStretch();



   this.RGBAlignSizer = new HorizontalSizer;
   this.RGBAlignSizer.spacing = 4;
   this.RGBAlignSizer.add(this.RGBFullImageAlignToolsSizer);
   this.RGBAlignSizer.addStretch();
   this.RGBAlignSizer.spacing = 4;
   this.RGBAlignSizer.add(this.RGBCornerAlignToolsSizer);


   this.RGXfactor = new NumericControl(this);
   this.RGXfactor.label.text = "Red Green X shift correction factor:";
   this.RGXfactor.toolTip = "Adds an extra multiplicative shift correction factor based on this value.";
   this.RGXfactor.setRange(0.2, 5);
   this.RGXfactor.setPrecision(2);
   // this.SSstarIntensityRange.slider.setRange(0, 1);
   this.RGXfactor.setValue(globalParameters.RGXfactor);
   // this.starSizeSlider.hide(); // Hide initially
   this.RGXfactor.onValueUpdated = (value) => {
      globalParameters.RGXfactor = value;
   };

   this.RGXfactorSizer = new HorizontalSizer;
   this.RGXfactorSizer.spacing = 4;
   this.RGXfactorSizer.add(this.RGXfactor);

   this.RGYfactor = new NumericControl(this);
   this.RGYfactor.label.text = "Red Green Y shift correction factor:";
   this.RGYfactor.toolTip = "Adds an extra multiplicative shift correction factor based on this value.";
   this.RGYfactor.setRange(0.2, 5);
   this.RGYfactor.setPrecision(2);
   // this.SSstarIntensityRange.slider.setRange(0, 1);
   this.RGYfactor.setValue(globalParameters.RGYfactor);
   // this.starSizeSlider.hide(); // Hide initially
   this.RGYfactor.onValueUpdated = (value) => {
      globalParameters.RGYfactor = value;
   };

   this.RGYfactorSizer = new HorizontalSizer;
   this.RGYfactorSizer.spacing = 4;
   this.RGYfactorSizer.add(this.RGYfactor);

   this.RBXfactor = new NumericControl(this);
   this.RBXfactor.label.text = "Red Blue X shift correction factor:";
   this.RBXfactor.toolTip = "Adds an extra multiplicative shift correction factor based on this value.";
   this.RBXfactor.setRange(0.2, 5);
   this.RBXfactor.setPrecision(2);
   // this.SSstarIntensityRange.slider.setRange(0, 1);
   this.RBXfactor.setValue(globalParameters.RBXfactor);
   // this.starSizeSlider.hide(); // Hide initially
   this.RBXfactor.onValueUpdated = (value) => {
      globalParameters.RBXfactor = value;
   };

   this.RBXfactorSizer = new HorizontalSizer;
   this.RBXfactorSizer.spacing = 4;
   this.RBXfactorSizer.add(this.RBXfactor);

   this.RBYfactor = new NumericControl(this);
   this.RBYfactor.label.text = "Red Blue Y shift correction factor:";
   this.RBYfactor.toolTip = "Adds an extra multiplicative shift correction factor based on this value.";
   this.RBYfactor.setRange(0.2, 5);
   this.RBYfactor.setPrecision(2);
   // this.SSstarIntensityRange.slider.setRange(0, 1);
   this.RBYfactor.setValue(globalParameters.RBYfactor);
   // this.starSizeSlider.hide(); // Hide initially
   this.RBYfactor.onValueUpdated = (value) => {
      globalParameters.RBYfactor = value;
   };

   this.RBYfactorSizer = new HorizontalSizer;
   this.RBYfactorSizer.spacing = 4;
   this.RBYfactorSizer.add(this.RBYfactor);




   with (this.RGBStarsTab) {
      sizer = new VerticalSizer(this.RGBStarsTab);
      // sizer = new HorizontalSizer;
      sizer.add(this.RGBStarsDescription);
      sizer.spacing = 6;
      sizer.add(this.RGXfactorSizer);
      sizer.spacing = 6;
      sizer.add(this.RGYfactorSizer);
      sizer.spacing = 6;
      sizer.add(this.RBXfactorSizer);
      sizer.spacing = 6;
      sizer.add(this.RBYfactorSizer);
      sizer.spacing = 6;
      sizer.add(this.RGBAlignSizer);
      sizer.spacing = 6;
      sizer.addStretch();
   }














   this.deblurTabBox = new TabBox(this);
   with (this.deblurTabBox) {

      addPage(this.RGBStarsTab, "Fix RGB Stars");
      addPage(this.syntheticStarsGeneratorTab, "Star Detector Settings");

      this.deblurTabBox.bindings = function () {
         this.enabled = globalParameters.targetView != null;
      }
   }




   this.lblState = new Label(this);
   this.lblState.text = "";

   this.lblStateSizer = new HorizontalSizer;
   this.lblStateSizer.spacing = 4;
   this.lblStateSizer.add(this.lblState);

   var progressValue = 0;

   this.progressBar = new Label(this);
   with (this.progressBar) {
      lineWidth = 1;
      frameStyle = FrameStyle_Box;
      textAlignment = TextAlign_Center | TextAlign_VertCenter;

      onPaint = function (x0, y0, x1, y1) {
         var g = new Graphics(dlg.progressBar);
         g.fillRect(x0, y0, x1, y1, new Brush(0xFFFFFFFF));
         if (progressValue > 0) {
            var l = (x1 - x0 + 1) * progressValue;
            g.fillRect(x0, y0, l, y1, new Brush(0xFF00EFE0));
         }
         g.end();
         text = (progressValue * 100).toFixed(0) + "%";
      }
   }

   this.progress = function (n) {
      progressValue = n;// Math.min(n, 1);
      dlg.progressBar.repaint();
   }


   // New Instance button
   this.newInstanceButton = new ToolButton(this);
   this.newInstanceButton.icon = this.scaledResource(":/process-interface/new-instance.png");
   this.newInstanceButton.setScaledFixedSize(24, 24);
   this.newInstanceButton.toolTip = "Save a new instance of this script";
   this.newInstanceButton.onMousePress = function () {
      this.dialog.newInstance();
   }.bind(this);

   this.undoRepairButton = new PushButton(this);
   this.undoRepairButton.text = "Undo";
   this.undoRepairButton.toolTip = "Undo the last repair";
   this.undoRepairButton.icon = ":/icons/undo.png";
   this.undoRepairButton.onClick = () => {
      if (globalParameters.targetWindow && !globalParameters.targetWindow.isNull) {
         globalParameters.targetWindow.undo();
      } else {
         console.writeln("No valid window selected for undo!");
      }
   };

   this.redoRepairButton = new PushButton(this);
   this.redoRepairButton.text = "Redo";
   this.redoRepairButton.toolTip = "Redo the last repair";
   this.redoRepairButton.icon = ":/icons/redo.png";
   this.redoRepairButton.onClick = () => {
      if (globalParameters.targetWindow && !globalParameters.targetWindow.isNull) {
         globalParameters.targetWindow.redo();
      } else {
         console.writeln("No valid window selected for redo!");
      }
   };

   this.buttonsSizer = new HorizontalSizer;
   this.buttonsSizer.spacing = 6;
   this.buttonsSizer.add(this.newInstanceButton);
   // this.buttonsSizer.add(this.setupButton);
   this.buttonsSizer.addStretch();
   this.buttonsSizer.add(this.undoRepairButton);
   this.buttonsSizer.spacing = 6;
   this.buttonsSizer.add(this.redoRepairButton);
   this.buttonsSizer.addStretch();


   this.buttonsSizer.addStretch();

   // Layout
   this.sizer = new VerticalSizer;
   this.sizer.margin = 6;
   this.sizer.spacing = 6;
   this.sizer.addStretch();
   this.sizer.add(this.title);
   this.sizer.add(this.description);
   this.sizer.addStretch();
   this.sizer.add(this.imageSelectionSizer);
   this.sizer.spacing = 6;
   this.sizer.add(this.deblurTabBox);
   this.sizer.spacing = 6;

   this.sizer.add(this.lblStateSizer);
   this.sizer.spacing = 8;
   this.sizer.add(this.progressBar);
   this.sizer.spacing = 6;

   this.sizer.addStretch();


   this.sizer.addSpacing(12);
   this.sizer.add(this.buttonsSizer);

   this.windowTitle = "RGBStarAlign Script";
   this.adjustToContents();


}


MainDialog.prototype = new Dialog;


// Main execution block for running the script
let dialog = new MainDialog();
console.show();
console.writeln("MainDialog process started.");
console.flush();

if (dialog.execute()) {
   let selectedIndex = dialog.imageSelectionDropdown.currentItem;
   let selectedView = ImageWindow.windows[selectedIndex];

   if (!selectedView) {
      console.criticalln("Please select an image.");
   } else {
       let artifactCorrectionFileWindow = ImageWindow.open(globalParameters.artifactCorrectionImageFile)[0];
      if (artifactCorrectionFileWindow) {
         artifactCorrectionFileWindow.show();
      }
   }
}


// -------------------------------------------------------------------------------------------------




function getStarsByRegion(view, dlg, channelNumber, xLowerPercent, xUpperPercent, yLowerPercent, yUpperPercent, marginFactor) {
   if ((xUpperPercent <= xLowerPercent) || (yUpperPercent <= yLowerPercent)) {
      Console.writeln("Invalid bounds xLowerPercent: " + xLowerPercent + ' xUpperPercent: ' + xUpperPercent + " yLowerPercent: " + yLowerPercent + ' yUpperPercent: ' + yUpperPercent);

      return [];
   }

   let returningStarList = [];

   let stringAppend = '_temp_R';

   if (channelNumber === GREEN_CHANNEL) {
      stringAppend = '_temp_G';
   }

   if (channelNumber === BLUE_CHANNEL) {
      stringAppend = '_temp_B';
   }

   Console.writeln("String append: " + stringAppend);

   let currentView = View.viewById(view.id + stringAppend);

   let originalWidth = currentView.image.width;
   let originalHeight = currentView.image.height;

   let xStart = xLowerPercent * originalWidth;
   let xEnd = xUpperPercent * originalWidth;

   let yStart = yLowerPercent * originalHeight;
   let yEnd = yUpperPercent * originalHeight;

   var P = new Crop;
   P.leftMargin = -1 * xStart + marginFactor;
   P.topMargin = -1 * yStart + marginFactor;
   P.rightMargin = xEnd - originalWidth + marginFactor;
   P.bottomMargin = yEnd - originalHeight + marginFactor;
   P.mode = Crop.prototype.AbsolutePixels;
   P.xResolution = 72.000;
   P.yResolution = 72.000;
   P.metric = false;
   P.forceResolution = false;
   P.red = 0.000000;
   P.green = 0.000000;
   P.blue = 0.000000;
   P.alpha = 1.000000;
   P.noGUIMessages = false;

   let intermediateImageWindow = new ImageWindow(currentView.image.width, currentView.image.height,
      currentView.image.numberOfChannels, // 1 channel for grayscale
      currentView.image.bitsPerSample,
      currentView.image.isReal,
      currentView.image.isColor
   );

   let intermediateImageView = intermediateImageWindow.mainView;
   intermediateImageView.beginProcess(UndoFlag_NoSwapFile);
   let intermediateImageImage = intermediateImageView.image;
   intermediateImageImage.apply(currentView.image);

   intermediateImageWindow.show();

   P.executeOn(intermediateImageView);

   Console.writeln("Original cropped to width: " + intermediateImageImage.width + ' height: ' + intermediateImageImage.height);

   let returningStarList = getStars(intermediateImageView, dlg);

   return [returningStarList, intermediateImageView];
}


function generateRGBStarLists(view, dlg, cornerPercent=0.1, cornerRegion='TopLeft', cornerOnly=false) {
   if (view.image.numberOfChannels > 1) {
      extractChannels(view);
   }
   else {
      Console.writeln("This image does not appear to be an RGB image as it has " + view.image.numberOfChannels + " channels");

      (new MessageBox("Not an RGB image", TITLE, StdIcon_Error, StdButton_Ok)).execute();

      return [];
   }

   let redChannelView = View.viewById(view.id + "_temp_R");
   let greenChannelView = View.viewById(view.id + "_temp_G");
   let blueChannelView = View.viewById(view.id + "_temp_B");

   let replacementImageWindow = new ImageWindow(view.image.width, view.image.height,
      view.image.numberOfChannels, // 1 channel for grayscale
      view.image.bitsPerSample,
      view.image.isReal,
      view.image.isColor
   );

   let replacementImageView = replacementImageWindow.mainView;
   replacementImageView.beginProcess(UndoFlag_NoSwapFile);
   let replacementImageImage = replacementImageView.image;
   replacementImageImage.fill(0);
   if (cornerOnly) {
      replacementImageImage.apply(view.image);
   } 
   replacementImageView.window.show();

   let spacingArray = [0, 0.1, 0.5, 0.9, 1];

   if (cornerOnly) {
      spacingArray = [0, 1];
   }

   const marginFactor = 2;
   let medianRGX = 0;
   let medianRGY = 0;
   let medianRBX = 0;
   let medianRBY = 0;

   var totalFrames = (spacingArray.length - 1) * (spacingArray.length - 1);
   var frameNumber = 1;

   for (var cropRow = 0; cropRow < spacingArray.length - 1; cropRow++) {
      for (var cropColumn = 0; cropColumn < spacingArray.length - 1; cropColumn++) {
         let xLowerPercent = spacingArray[cropColumn];
         let xUpperPercent = spacingArray[cropColumn + 1];
         let yLowerPercent = spacingArray[cropRow];
         let yUpperPercent = spacingArray[cropRow + 1];

         if (cornerOnly) {
            if (cornerRegion == 'TopLeft') {
               xLowerPercent = 0;
               xUpperPercent = cornerPercent;
               yLowerPercent = 0;
               yUpperPercent = cornerPercent;
            }
            else if (cornerRegion == 'TopRight') {
               xLowerPercent = 1 - cornerPercent;
               xUpperPercent = 1;
               yLowerPercent = 0;
               yUpperPercent = cornerPercent;
            }
            else if (cornerRegion == 'BottomLeft') {
               xLowerPercent = 0;
               xUpperPercent = cornerPercent;
               yLowerPercent = 1 - cornerPercent;
               yUpperPercent = 1;
            }
            else {
               xLowerPercent = 1 - cornerPercent;
               xUpperPercent = 1;
               yLowerPercent = 1 - cornerPercent;
               yUpperPercent = 1;
            }
         }


         let [redStarList, redChannelCropView] = getStarsByRegion(view, dlg, RED_CHANNEL, xLowerPercent, xUpperPercent, yLowerPercent, yUpperPercent, marginFactor);
         let [greenStarList, greenChannelCropView] = getStarsByRegion(view, dlg, GREEN_CHANNEL, xLowerPercent, xUpperPercent, yLowerPercent, yUpperPercent, marginFactor);
         let [blueStarList, blueChannelCropView] = getStarsByRegion(view, dlg, BLUE_CHANNEL, xLowerPercent, xUpperPercent, yLowerPercent, yUpperPercent, marginFactor);

         Console.writeln("Returned " + redStarList.length + " red stars");
         Console.writeln("Returned " + greenStarList.length + " green stars");
         Console.writeln("Returned " + blueStarList.length + " blue stars");

         // pass through the red star list and find the closest green star peak to each star

         let maximumClosestDistance = 5;

         let RGBtripletList = [];

         for (var rIndex = 0; rIndex < redStarList.length; ++rIndex) {
            let currentRedStar = redStarList[rIndex];

            let redCenterX = currentRedStar.cx;
            let redCenterY = currentRedStar.cy;

            let closestGreenToRedX = 1000;
            let closestGreenToRedY = 1000;
            let closestGreenToRedDistance = 1000000;

            let currentClosestGreenStar = [];
            let currentClosestGreenStarIndex = -1;

            for (var gIndex = 0; gIndex < greenStarList.length; gIndex++) {
               let currentGreenStar = greenStarList[gIndex];

               let currentDistance = (redCenterX - currentGreenStar.cx) * (redCenterX - currentGreenStar.cx) + (redCenterY - currentGreenStar.cy) * (redCenterY - currentGreenStar.cy)

               if (currentDistance < closestGreenToRedDistance) {
                  closestGreenToRedDistance = currentDistance;
                  currentClosestGreenStar = currentGreenStar;
                  currentClosestGreenStarIndex = gIndex;
               }
            }

            let closestBlueToRedX = 1000;
            let closestBlueToRedY = 1000;
            let closestBlueToRedDistance = 1000000;

            let currentClosestBlueStar = [];
            let currentClosestBlueStarIndex = -1;


            for (var bIndex = 0; bIndex < blueStarList.length; bIndex++) {
               let currentBlueStar = blueStarList[bIndex];

               let currentDistance = (redCenterX - currentBlueStar.cx) * (redCenterX - currentBlueStar.cx) + (redCenterY - currentBlueStar.cy) * (redCenterY - currentBlueStar.cy)

               if (currentDistance < closestBlueToRedDistance) {
                  closestBlueToRedDistance = currentDistance;
                  currentClosestBlueStar = currentBlueStar;
                  currentClosestBlueStarIndex = bIndex;
               }
            }

            if ((closestGreenToRedDistance < maximumClosestDistance) && (closestBlueToRedDistance < maximumClosestDistance)) {
               // Create an RGB star location triplet
               RGBtripletList.push([currentRedStar, currentClosestGreenStar, currentClosestBlueStar]);

               greenStarList.splice(currentClosestGreenStarIndex, 1);
               blueStarList.splice(currentClosestBlueStarIndex, 1);
            }
         }

         Console.writeln("Found " + RGBtripletList.length + " triplets");

         // Grab the offsets from the dimmest 50 stars
         let redGreenDifferenceListX = [];
         let redGreenDifferenceListY = [];
         let redBlueDifferenceListX = [];
         let redBlueDifferenceListY = [];

         var maxMedianListLength = 50;

         for (var RGBIndex = RGBtripletList.length - 1; RGBIndex > -1 && RGBtripletList.length - RGBIndex < maxMedianListLength + 1; RGBIndex--) {
            let [redStar, greenStar, blueStar] = RGBtripletList[RGBIndex];

            let redGreenDifferenceX = redStar.cx - greenStar.cx;
            let redGreenDifferenceY = redStar.cy - greenStar.cy;
            let redBlueDifferenceX = redStar.cx - blueStar.cx;
            let redBlueDifferenceY = redStar.cy - blueStar.cy;

            redGreenDifferenceListX.push(redGreenDifferenceX);
            redGreenDifferenceListY.push(redGreenDifferenceY);
            redBlueDifferenceListX.push(redBlueDifferenceX);
            redBlueDifferenceListY.push(redBlueDifferenceY);
         }

         medianRGX = medianOfList(redGreenDifferenceListX);
         medianRGY = medianOfList(redGreenDifferenceListY);
         medianRBX = medianOfList(redBlueDifferenceListX);
         medianRBY = medianOfList(redBlueDifferenceListY);

         Console.writeln("medianRGX: " + medianRGX + " medianRGY: " + medianRGY + " medianRBX: " + medianRBX + " medianRBY: " + medianRBY);
         Console.writeln("medianRBX length: " + redBlueDifferenceListX.length);

         let intermediateImageWindow = new ImageWindow(redChannelCropView.image.width, redChannelCropView.image.height,
            view.image.numberOfChannels, // 1 channel for grayscale
            view.image.bitsPerSample,
            view.image.isReal,
            view.image.isColor
         );

         let intermediateImageView = intermediateImageWindow.mainView;
         intermediateImageView.beginProcess(UndoFlag_NoSwapFile);
         let intermediateImageImage = intermediateImageView.image;
         intermediateImageImage.fill(0);

         intermediateImageWindow.show();

         combine(redChannelCropView, greenChannelCropView, blueChannelCropView, intermediateImageView);

         redChannelCropView.window.forceClose();
         greenChannelCropView.window.forceClose();
         blueChannelCropView.window.forceClose();

         var generalScaleFactor = 1;

         var P = new ChannelMatch;
         P.channels = [ // enabled, dx, dy, k
            [true, 0.00, 0.00, 1.00000000],
            [true, medianRGX * globalParameters.RGXfactor * generalScaleFactor, medianRGY * globalParameters.RGYfactor * generalScaleFactor, 1.00000000],
            [true, medianRBX * globalParameters.RBXfactor * generalScaleFactor, medianRBY * globalParameters.RBYfactor * generalScaleFactor, 1.00000000]
         ];

         P.executeOn(intermediateImageView);

         var P = new Crop;
         P.leftMargin = -1 * marginFactor;
         P.topMargin = -1 * marginFactor;
         P.rightMargin = -1 * marginFactor;
         P.bottomMargin = -1 * marginFactor;
         P.mode = Crop.prototype.AbsolutePixels;
         P.xResolution = 72.000;
         P.yResolution = 72.000;
         P.metric = false;
         P.forceResolution = false;
         P.red = 0.000000;
         P.green = 0.000000;
         P.blue = 0.000000;
         P.alpha = 1.000000;
         P.noGUIMessages = false;

         P.executeOn(intermediateImageView);

         let cropImageWindow = new ImageWindow(intermediateImageView.image.width, intermediateImageView.image.height,
            intermediateImageView.image.numberOfChannels, // 1 channel for grayscale
            intermediateImageView.image.bitsPerSample,
            intermediateImageView.image.isReal,
            intermediateImageView.image.isColor
         );

         let cropImageView = cropImageWindow.mainView;
         cropImageView.beginProcess(UndoFlag_NoSwapFile);
         let cropImage = cropImageView.image;
         cropImage.fill(1);

         cropImageWindow.show();


         // Now add the corrected subimage to the replacement image

         let originalWidth = view.image.width;
         let originalHeight = view.image.height;

         let xStart = xLowerPercent * originalWidth;
         let xEnd = xUpperPercent * originalWidth;

         let yStart = yLowerPercent * originalHeight;
         let yEnd = yUpperPercent * originalHeight;

         P.leftMargin = xStart;
         P.topMargin = yStart;
         P.rightMargin = originalWidth - xEnd;
         P.bottomMargin = originalHeight - yEnd;

         P.executeOn(intermediateImageView);
         P.executeOn(cropImageView);

         var P = new PixelMath;
         if (!cornerOnly) {
            P.expression = "max(" + replacementImageView.id + ", " + intermediateImageView.id + ")";
         }
         else {
            P.expression = "max(" + replacementImageView.id + "*~" + cropImageView.id + ", " + intermediateImageView.id + ")";
         }
         P.expression1 = "";
         P.expression2 = "";
         P.expression3 = "";
         P.useSingleExpression = true;
         P.symbols = "";
         P.clearImageCacheAndExit = false;
         P.cacheGeneratedImages = false;
         P.generateOutput = true;
         P.singleThreaded = false;
         P.optimization = true;
         P.use64BitWorkingImage = false;
         P.rescale = false;
         P.rescaleLower = 0;
         P.rescaleUpper = 1;
         P.truncate = true;
         P.truncateLower = 0;
         P.truncateUpper = 1;
         P.createNewImage = false;
         P.showNewImage = true;
         P.newImageId = "";
         P.newImageWidth = 0;
         P.newImageHeight = 0;
         P.newImageAlpha = false;
         P.newImageColorSpace = PixelMath.prototype.SameAsTarget;
         P.newImageSampleFormat = PixelMath.prototype.SameAsTarget;

         P.executeOn(replacementImageView);

         intermediateImageWindow.forceClose();
         cropImageWindow.forceClose();

         var progress = frameNumber / totalFrames;

         dlg.progress(progress);

         frameNumber = frameNumber + 1;
      }
   }

   view.beginProcess(UndoFlag_NoSwapFile);

   var P = new PixelMath;
   P.expression = "" + replacementImageView.id + "";
   P.expression1 = "";
   P.expression2 = "";
   P.expression3 = "";
   P.useSingleExpression = true;
   P.symbols = "";
   P.clearImageCacheAndExit = false;
   P.cacheGeneratedImages = false;
   P.generateOutput = true;
   P.singleThreaded = false;
   P.optimization = true;
   P.use64BitWorkingImage = false;
   P.rescale = false;
   P.rescaleLower = 0;
   P.rescaleUpper = 1;
   P.truncate = true;
   P.truncateLower = 0;
   P.truncateUpper = 1;
   P.createNewImage = false;
   P.showNewImage = true;
   P.newImageId = "";
   P.newImageWidth = 0;
   P.newImageHeight = 0;
   P.newImageAlpha = false;
   P.newImageColorSpace = PixelMath.prototype.SameAsTarget;
   P.newImageSampleFormat = PixelMath.prototype.SameAsTarget;

   P.executeOn(view);

   redChannelView.window.forceClose();
   greenChannelView.window.forceClose();
   blueChannelView.window.forceClose();

   replacementImageWindow.forceClose();

   // Console.writeln("medianRGX: " + medianRGX + " medianRGY: " + medianRGY + " medianRBX: " + medianRBX + " medianRBY: " + medianRBY);
   dlg.lblState.text = 'Shifted G->R (' + medianRGX + ', ' + medianRGY + ') B->R (' + medianRBX + ', ' + medianRBY + ')';
   processEvents();

   return [];
}

